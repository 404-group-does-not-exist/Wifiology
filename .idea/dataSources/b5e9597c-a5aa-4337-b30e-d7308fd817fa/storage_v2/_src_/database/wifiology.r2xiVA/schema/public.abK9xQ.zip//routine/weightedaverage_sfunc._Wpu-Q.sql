create function weightedaverage_sfunc(aggstate point, avg real, weight real) returns point
  language plpgsql
as
$$
BEGIN
    IF (avg IS NOT NULL) AND (weight IS NOT NULL) THEN
       RETURN point(aggState[0] + avg*weight, aggState[1] + weight);
    ELSE
       RETURN aggState;
    END IF;
  END;
$$;

alter function weightedaverage_sfunc(point, real, real) owner to rpcope;

