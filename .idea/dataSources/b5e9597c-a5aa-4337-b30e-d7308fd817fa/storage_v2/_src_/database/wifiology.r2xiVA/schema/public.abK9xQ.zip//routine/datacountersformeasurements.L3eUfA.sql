create function datacountersformeasurements(measurementids bigint[]) returns TABLE(measurementid bigint, managementframecount bigint, associationframecount bigint, reassociationframecount bigint, disassociationframecount bigint, controlframecount bigint, rtsframecount bigint, ctsframecount bigint, ackframecount bigint, dataframecount bigint, datathroughputin bigint, datathroughputout bigint, retrycount bigint, averagepower real, stddevpower real, lowestrate integer, higestrate integer, failedfcscount bigint)
  language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
    mapMeasurementID AS measurementID,
    SUM(m.managementFrameCount) AS managementFrameCount,
    SUM(m.associationFrameCount) AS associationFrameCount,
    SUM(m.reassociationFrameCount) AS reassociationFrameCount,
    SUM(m.disassociationFrameCount) AS disassociationFrameCount,
    SUM(m.controlFrameCount) AS controlFrameCount,
    SUM(m.rtsFrameCount) AS rtsFrameCount,
    SUM(m.ctsFrameCount) AS ctsFrameCount,
    SUM(m.ackFrameCount) AS ackFrameCount,
    SUM(m.dataFrameCount) AS dataFrameCount,
    SUM(m.dataThroughputIn) AS dataThroughputIn,
    SUM(m.dataThroughputOut) AS dataThroughputOut,
    SUM(m.retryFrameCount) AS retryFrameCount,
    weightedAverage(
        m.averagePower::REAL,
        (m.managementFrameCount + m.controlFrameCount + m.dataFrameCount)::REAL
    )::REAL AS averagePower,
    weightedStdDev(
        m.stdDevPower::REAL,
        (m.managementFrameCount + m.controlFrameCount + m.dataFrameCount)::REAL
    )::REAL AS stdDevPower,
    MIN(m.lowestRate) AS lowestRate,
    MAX(m.highestRate) AS highestRate,
    SUM(m.failedFCSCount) AS failedFCSCount
FROM measurementstationmap AS m
GROUP BY m.mapmeasurementid
HAVING m.mapmeasurementID = ANY(measurementIDs);
END;
$$;

alter function datacountersformeasurements(bigint[]) owner to rpcope;

