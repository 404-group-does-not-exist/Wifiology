create function weightedstddev_sfunc(aggstate point, stddev real, weight real) returns point
  language plpgsql
as
$$
BEGIN
    IF (stdDev IS NOT NULL) AND (weight IS NOT NULL) THEN
       RETURN point(aggState[0] + stdDev*stdDev*weight, aggState[1] + weight);
    ELSE
       RETURN aggState;
    END IF;
  END;
$$;

alter function weightedstddev_sfunc(point, real, real) owner to rpcope;

