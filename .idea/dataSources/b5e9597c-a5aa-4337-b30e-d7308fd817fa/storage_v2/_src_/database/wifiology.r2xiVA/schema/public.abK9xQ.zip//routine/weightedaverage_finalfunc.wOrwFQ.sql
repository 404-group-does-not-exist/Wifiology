create function weightedaverage_finalfunc(aggstate point) returns real
  language plpgsql
as
$$
begin
    IF(aggState[1] = 0) THEN
        RETURN NULL;
    ELSE
        return aggState[0]/aggState[1];
    END IF;
  end;
$$;

alter function weightedaverage_finalfunc(point) owner to rpcope;

